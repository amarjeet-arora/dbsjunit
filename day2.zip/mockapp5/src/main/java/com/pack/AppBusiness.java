package com.pack;

import java.util.ArrayList;
import java.util.List;

public class AppBusiness {
	
	public AppService appService;

	public AppBusiness(AppService appService) {
		 
		this.appService = appService;
	}
	
	public List<String> getUserForAdmin(String user){
		List<String> adminlist= new ArrayList<String>();
		List<String> combineList= appService.getUsers(user);
		
		for(String usr: combineList) {
			if(usr.contains("admin")) {
				adminlist.add(usr);
			}
			
		}
		return adminlist;
	}
	
	public void deleteForAdmin(String user){
		 
		List<String> combineList= appService.getUsers(user);
		
		for(String usr: combineList) {
			if(!usr.contains("admin")) {
			appService.deleteUsers(usr);
			}
			
		}
		 
	}
	
}
