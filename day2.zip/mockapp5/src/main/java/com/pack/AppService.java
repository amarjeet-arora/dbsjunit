package com.pack;

import java.util.List;

public interface AppService {
	
	public List<String> getUsers(String user);
	public void deleteUsers(String user);

}
