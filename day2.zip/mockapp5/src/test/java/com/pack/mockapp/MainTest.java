package com.pack.mockapp;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;

import com.pack.AppBusiness;
import com.pack.AppService;

public class MainTest {
    @Mock
	AppService appService;
    @InjectMocks
    AppBusiness appBusiness;
    @Captor
    ArgumentCaptor<String> argumentCaptor;
    @Spy
    ArrayList<String> aryspy;
    
    @Test
    public void deleteUser() {
    	List<String> cbd= Arrays.asList("admin","manager","qa");
    	
    	Mockito.when(appService.getUsers("dummy")).thenReturn(cbd);
    	aryspy.add("mok1");
    	aryspy.add("mok2");
    	//when
    	appBusiness.deleteForAdmin("dummy");
    	
    	Mockito.verify(aryspy).add("mok1");
    	Mockito.verify(aryspy).add("mok2");
    	
    	Mockito.verify(appService,Mockito.times(1)).deleteUsers("admin");
    	Mockito.verify(appService,Mockito.never()).deleteUsers("manager");
    	Mockito.verify(appService,Mockito.never()).deleteUsers("qa");
    	assertEquals(2, aryspy.size());
    	//assertEquals(argumentCaptor.getValue(),, 0);


    }
    
    
    
    
    
}
