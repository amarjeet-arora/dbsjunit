package com.pack.mockapp;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

import com.pack.MathApp;

public class MathTest {
@Test
	public void testApp() {
	MathApp math= Mockito.mock(MathApp.class);
	Mockito.when(math.add(12,13)).thenReturn(25);
	
	Mockito.when(math.isInt(Mockito.anyString())).thenReturn(true);
	
	ArgumentCaptor aci= ArgumentCaptor.forClass(Integer.class);
	ArgumentCaptor acs= ArgumentCaptor.forClass(String.class);
	
	assertEquals(25,math.add(12,13));
	Mockito.verify(math).add(aci.capture(),aci.capture());

		
	}
}
