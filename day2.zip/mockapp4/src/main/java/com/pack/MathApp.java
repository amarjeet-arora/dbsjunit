package com.pack;

public class MathApp {

	public int add(int x,int y) {
		return x+y;
	}
	
	public boolean isInt(String s1) {
		try {
			Integer.parseInt(s1);
		}catch (Exception e) {
			 return false;
		}
		return true;
	}
	public long longapp(long l) {
		return l*l;
	}
}

