package com.pack.mockapp;

import java.util.ArrayList;
import java.util.List;

public class AppBusiness {
	
	private AppService appService;

	public AppBusiness(AppService appService) {
		super();
		this.appService = appService;
	}
	
public List<String> loadData(String user){
	
	List<String> rtd= new ArrayList<String>();
	List<String> td= appService.loadData(user);
	
	for(String tds: td) {
		if(tds.contains("admin")) {
			rtd.add(tds);
		}
	}
	return rtd;
}
}
