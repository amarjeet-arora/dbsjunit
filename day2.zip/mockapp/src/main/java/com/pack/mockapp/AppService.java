package com.pack.mockapp;

import java.util.List;

public interface AppService {
	public List<String> loadData(String user);

}
