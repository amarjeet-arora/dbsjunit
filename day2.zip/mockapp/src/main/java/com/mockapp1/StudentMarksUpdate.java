package com.mockapp1;

public class StudentMarksUpdate {
	private IDatabase database;

	public StudentMarksUpdate(IDatabase database) {
		super();
		this.database = database;
	}
	
	public void calculateMarksandStore(String sid,int[]marks) {
		int total =0;
		for(int score : marks) {
			total =total+score;
		}
		database.updateMarks(sid, total);
	}
	

}
