package com.mockapp1;

public interface IDatabase {
	public void updateMarks(String sid,int total);

}
