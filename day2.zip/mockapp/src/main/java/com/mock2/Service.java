package com.mock2;

public class Service {
	private Database database;

	public Service(Database database) {
		super();
		this.database = database;
	}

	public boolean query(String query) {
		return database.isAvailable();
	}

	@Override
	public String toString() {
		return "Using datab with id" + String.valueOf(database.getUId());
	}
	
}
