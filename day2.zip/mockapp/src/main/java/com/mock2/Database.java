package com.mock2;

public class Database {
	public boolean isAvailable() {
		return false;
	}
	
	public int getUId() {
		return 40;
	}

}
