package com.pack.mockapp;

 

 import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
 import static org.mockito.Mockito.when;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

public class AppServicetest2 {
	 @Test
	public void testScen() {
		 
		 AppService appService= mock(AppService.class);
		List<String> cd= Arrays.asList("admin1","manager1","qa1");
		
		when(appService.loadData("dummy")).thenReturn(cd);
		
		AppBusiness business= new AppBusiness(appService);
		
		List<String> alltd= business.loadData("dummy");
		System.out.println(alltd);
		assertEquals(1, alltd.size());
		
	}

}
