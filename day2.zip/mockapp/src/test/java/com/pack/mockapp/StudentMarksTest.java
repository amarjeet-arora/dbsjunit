package com.pack.mockapp;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito.*;
import org.mockito.MockitoAnnotations;
 import com.mockapp1.IDatabase;
import com.mockapp1.StudentMarksUpdate;

public class StudentMarksTest {
	@Mock
	public IDatabase database;
	
	public StudentMarksUpdate marksUpdate;
	
	@BeforeEach
	public void beforeEach() {
		MockitoAnnotations.initMocks(this);
	}
	@Test
	public void calculateTest() {
		marksUpdate= new StudentMarksUpdate(database);
		int[] marks= {60,70,90};
		Mockito.doNothing().when(database).updateMarks(anyString(),anyInt());
		
		marksUpdate.calculateMarksandStore("student1", marks);
		Mockito.verify(marksUpdate,Mockito.times(1)).updateMarks("student1",230);
	}
	

}
