package com.pack.mockapp;

 

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.Test;

public class AppServicetest {
	 @Test
	public void testScen() {
		
		AppService aServiceStub=new AppServiceStub();
		
		AppBusiness ab= new AppBusiness(aServiceStub);
		
		List<String> rtd= ab.loadData("dummy");
		assertEquals(1, rtd.size());
	}

}
