package com.pack.mockapp;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import static org.mockito.Mockito.when;

import com.mock2.Database;
import com.mock2.Service;

@ExtendWith(MockitoExtension.class)
public class Servicetest {

	@Mock
	Database database;
	@Test
	public void testQuery() {
		assertNotNull(database);
		when(database.isAvailable()).thenReturn(true);
		
		Service t= new Service(database);
		boolean check=t.query("* from t");
		assertTrue(check);
	}
	
	
	
	
}
