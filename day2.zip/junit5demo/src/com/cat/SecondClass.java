package com.cat;

import org.junit.Test;
import org.junit.experimental.categories.Category;


@Category({NewTest.class,AppTest.class})
public class SecondClass {

	
	
	@Test
	public void method3() {
		
	}
}
