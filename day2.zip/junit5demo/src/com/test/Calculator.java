package com.test;

import java.util.StringTokenizer;

public class Calculator {
	
	public int add(int a,int b) {
		return a+b;
	}
	
	
	
	public int mul(int a,int b) {
		return a*b;
	}
	
	
	public static int findBigNum(int arr[]) {
		int max=arr[0];
		for(int i=0;i< arr.length;i++) {
			if(max<arr[i]) {
				max=arr[i];
			}
			
		}
		return max;
	}
	
	
	public static String reverseApp(String input) {
		StringBuilder data= new StringBuilder();
		StringTokenizer st= new StringTokenizer(input,"");
		while(st.hasMoreTokens()) {
			StringBuilder sb= new StringBuilder();
			sb.append(st.nextToken());
			sb.reverse();
			data.append(sb);
			data.append("");
		}
		return data.toString();
	}
	
	public int showData(int i) {
		return i;
	}

}
