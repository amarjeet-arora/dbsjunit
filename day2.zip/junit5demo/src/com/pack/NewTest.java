package com.pack;

import static org.junit.jupiter.api.Assertions.assertEquals;

 
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;

@DisplayName("Testcase for calculations")
public class NewTest {
@Test
@RepeatedTest(value=1, name="shortname")
	public void add() {
		int a=10;
		int b=20;
		assertEquals(30, (a+b));
	}
}
