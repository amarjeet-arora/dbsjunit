package com.nesteddemo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;
import org.junit.jupiter.api.Nested;

public class UserLogin {
	
	public void verifyLogin(String id) {
		id="user01";
		assertEquals(id,  "user01" ,"valid login id");
		System.out.println("Outer class - FB Login");
	}
	@Nested
	class NestedPasswordApp() {
		@Test
		public void verifyPassword(String pass) {
			pass="pass@123";
			assertEquals(pass,"pass@123","valid password");
			System.out.println("innside nested");
		}
	}

}
