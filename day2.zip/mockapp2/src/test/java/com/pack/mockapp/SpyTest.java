package com.pack.mockapp;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;
import org.junit.jupiter.api.Test;
import org.mockito.Spy;

public class SpyTest {

	@Test
	public void testSpy() {
		
		List<String> list= new ArrayList<String>();
		List<String> spyonlist= spy(list);
		 
		
		spyonlist.add("A");
		assertEquals(1, spyonlist.size());
		assertEquals("A", spyonlist.get(0));
		
		spyonlist.add("B");
		assertEquals(2, spyonlist.size());
		assertEquals("B", spyonlist.get(1));
		
		when(spyonlist.size()).thenReturn(10);
		assertEquals(10, spyonlist.size());
		
		
		 
 	}
}
