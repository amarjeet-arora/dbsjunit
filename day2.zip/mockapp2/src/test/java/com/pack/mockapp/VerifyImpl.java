package com.pack.mockapp;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.times;
 import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatcher;
import org.mockito.Mockito;

public class VerifyImpl {
   @Test
	public void test() {
	
	   List<String> mockList=mock(List.class);
	   
	   mockList.add("amar");
	   mockList.size();
	   //mockList.size();
	   verify(mockList).add("amar");
	   verify(mockList).add(anyString());
	   verify(mockList).add(ArgumentMatcher.any(String.class);
	   //verify(mockList,times(2)).size();
	   
	   
	   
	}
}
