package com.pack;

import java.util.List;

public class Game {
	
	private Player player;
	
	private List<String> opp;

	 
	
	public Game(Player player, List<String> opp) {
		super();
		this.player = player;
		this.opp = opp;
	}

public int nop() {
	return opp.size();
}

	public String attack() {
		return "player attcak with " + player.getWeapon();
	}

}
