package com.pack;

public class MockPrivateApp {
	public String getDetails() {
		return "";
	}
	private String getDetails2() {
		return "";
	}
}
