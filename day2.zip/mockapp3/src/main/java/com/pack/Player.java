package com.pack;

public class Player {
	private String weapon;

	public Player() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Player(String weapon) {
		super();
		this.weapon = weapon;
	}

	public String getWeapon() {
		return weapon;
	}

	public void setWeapon(String weapon) {
		this.weapon = weapon;
	}

}
