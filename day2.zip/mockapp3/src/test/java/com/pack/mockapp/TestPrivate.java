package com.pack.mockapp;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import com.pack.MockPrivateApp;

@Runwith(PowerMockRunner.class)
@PrepareForTest(PriceCalculator.class)
public class TestPrivate {

	private static final String METHOD="getDetails2";
	private MockPrivateApp app;
	@Test
	public void testApp() {
		app= new MockPrivateApp();
		MockPrivateApp spy= PowerMockito.spy(app);
		PowerMockito.doReturn("test").when(spy,METHOD);
		String value=spy.getDetails2();
	assertEquals(value, "");
	PowerMockito.veriFyPrivate(spy,Mockito.times(1)).invoke(METHOD);
	}
}
