package com.pack.mockapp;

public class Snippet {
	@Test
	@PrepareForTest(PriceCalculator.class)
	public void calculatePriceForAnonymous_witStubbedPrivateMethod_returnsCorrectPrice() throws Exception {
	// Arrange
	ItemSku item1 = new ItemSku();
	item1.setApplicableDiscount(5.00);
	item1.setPrice(100.00);
	 
	  double expectedPrice = 90.00;
	 
	// Setting up stubbed responses using mocks
	when(priceCalculatorSpy, "isCustomerAnonymous").thenReturn(false);
	when(mockedItemService.getItemDetails(123)).thenReturn(item1);
	 
	// Act
	double actualDiscountedPrice = priceCalculatorSpy.calculatePriceWithPrivateMethod(123);
	 
	// Assert
	verifyPrivate(priceCalculator).invoke("isCustomerAnonymous");
	assertEquals(expectedPrice, actualDiscountedPrice);
	}
}

