package com.pack.mockapp;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;

import com.pack.Game;
import com.pack.Player;

public class GameTst2 {
	@Mock
	Player player;
	@Spy
	List<String> enmies= new ArrayList<String>();
	@InjectMocks
	Game game;
	
	public void attackTest() {
		Mockito.when(player.getWeapon()).thenReturn("sward");
		enmies.add("dragon");
		enmies.add("dra2");
		assertEquals(2, game.nop());
		assertEquals("player attck",game.attack() );
	}

}
