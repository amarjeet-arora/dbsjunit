package com.pack.mockapp;

import org.mockito.InjectMocks;
import org.mockito.Mock;

import com.pack.Game;
import com.pack.Player;

public class GameTest {

	@Mock
	//mock it using when and then return
	Player player;
	@InjectMocks
	Game game;
	//Game game= new Game(player);
}
