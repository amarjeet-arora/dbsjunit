package com.pm;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;

import com.test.Calculator;
@RunWith(Parameterized.class)
public class ParameterDemo {
	 
	public int m1;
	 
	public int m2;
	 
	
	 
 	
	public ParameterDemo(int m1, int m2) {
		 
		this.m1 = m1;
		this.m2 = m2;
	}
	@Parameters
	public static Collection<Object[]> userdata(){
		Object[][] data= new Object[][] {{1,2},{5,3},{121,4}};
		return Arrays.asList(data);
	}
	@Test
	public void testMultiply() {
		Calculator c= new Calculator();
		assertEquals(m1*m2, c.mul(m1, m2));
	}
	@Test
	
	public void testAdd() {
		Calculator c= new Calculator();
		assertEquals(m1+m2, c.add(m1, m2));
	}
	
	
	
	
	
	
	
	
	

}
