package com.testapp;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.exception.ProductNotFound;
import com.model.Product;
import com.model.ShoppingCart;

public class ShoppingTest {
	
	private ShoppingCart cart;
	private Product book1;
	private Product book2;
    @Before
	public void setUp() {
		cart= new ShoppingCart();
		book1= new Product("java book", 234.00);
		book2= new Product("C# book", 220.00);
		cart.addItem(book1);
		cart.addItem(book2);
	}
	@Test
    public void testAdd() {
    	Product book3= new Product("MongoDB", 330.00);
    	cart.addItem(book3);
    	assertEquals(3, cart.getItemCount());
    	
    	
    	
    }
	public void testForNoProduct() {
	try {
		Product book3= new Product("MongoDB", 330.00);
		cart.removeItem(book3);
		
	}catch (ProductNotFound e) {
		fail(" Should raise an exception");
		 
	}
	}
	
	
	@Test(expected = IndexOutOfBoundsException.class)
	public void testEmpty() {
		new ArrayList<Object>().get(0);
	}
	
	
	
	
}
