package com.cat;

public interface NewTest {

}
