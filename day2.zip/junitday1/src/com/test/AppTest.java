package com.test;

import static org.junit.Assert.assertEquals;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
//@Ignore
public class AppTest {
	private static Calculator calc;
	//get called only once all test method
	@BeforeClass
	public static void callBeforeClass() {
		System.out.println("calling before");
		calc= new Calculator();
	}
	@AfterClass
	public static void callAfterClass() {
		System.out.println("calling after all");
		calc= null;
	}
	//get called before every test method
	@Before
	public void setUp() {
		System.out.println("inside before");
		
		
	}
	@Test(timeout = 1000)
	public void testAdd() {
		try {
			Thread.sleep(1200);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertEquals("testing the addition",10, calc.add(5, 5));
		
		
		
		
		
	}@Test
	public void testAdd2() {
		assertEquals("testing the addition",11, calc.add(6, 5));
	}

}
