package com.model;

import java.util.ArrayList;
import java.util.Iterator;

import com.exception.ProductNotFound;

public class ShoppingCart {
	private ArrayList<Product> al;
	
	public ShoppingCart(){
		al= new ArrayList<Product>();
	}
	public int getItemCount() {
		return al.size();
	}
	public void addItem(Product product) {
		al.add(product);
	}
	public double getBalance() {
		double balance=0.0;
		for(Iterator i= al.iterator(); i.hasNext();) {
			Product item=(Product)i.next();
			balance+=item.getPrice();
		}
		return balance;
	}
	public void removeItem(Product product) throws ProductNotFound {
		
		if(!al.remove(product)) {
			throw new ProductNotFound();
		}
	}

}
