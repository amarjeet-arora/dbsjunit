package com.rules;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

public class RuleDemo3 {

	public static String log;
	
	private final CountDownLatch latch= new CountDownLatch(1);
	@Rule
	public Timeout globaltOut= Timeout.seconds(20);
	@Test(timeout = 5000)
	public void test1() throws Exception {
		log += "r-1";
		TimeUnit.SECONDS.sleep(10);
	}
	@Test
	public void test2() throws Exception {
		log += "r-2";
		latch.await();
	}
	
}
