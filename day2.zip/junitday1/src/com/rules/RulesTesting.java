package com.rules;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import com.test.Calculator;

public class RulesTesting {

	
	@Rule
	public ExpectedException exception= ExpectedException.none();
	
	
	@Test
	public void throwExceptionDemo() {
		exception.expect(IllegalArgumentException.class);
		exception.expectMessage("Negative value not  allowed");
		Calculator c= new Calculator();
		c.showData(-2);
	}
}



