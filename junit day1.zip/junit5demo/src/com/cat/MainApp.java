package com.cat;

import org.junit.platform.suite.api.ExcludePackages;
import org.junit.platform.suite.api.IncludeTags;
import org.junit.platform.suite.api.SelectPackages;

@SelectPackages("com.model")
@IncludeTags({"prod","UD"})
@ExcludePackages("com.notneeded")
public class MainApp {

}
