package com.cat;

import static org.junit.Assert.fail;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.jupiter.api.Tag;
@Tag("dev")
public class FIrstClass {
	 
	@Test
	@Tag("UM")
	
	@Tag("prod")
	public void testA() {
		
	}
}
