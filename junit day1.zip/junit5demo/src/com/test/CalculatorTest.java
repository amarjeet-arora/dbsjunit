package com.test;

import static org.junit.Assert.*;

import org.junit.After;
 import org.junit.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;

public class CalculatorTest {
	
	int a=1;
	
	

	@BeforeAll
	public static void callBeforeAll() {
		 
		System.out.println("called before All test");
	}
	
	
	@BeforeEach
	public void callBefore() {
		a=10;
		System.out.println("called before test");
	}
	@AfterEach
	public void callAfter() {
		System.out.println(a);
	}

	@Test
	@Disabled
	public void testAdd() {
		++a;
		System.out.println(a);
		assertEquals(10, new Calculator().add(5, 5));
		
	}
	@Test
	public void welcomeTest() {
		++a;
		System.out.println(a);
		assertEquals("welcome", "welcome");
	}
	@Test
	public  void findBigTest() {
		System.out.println(a);
		assertEquals(10, new Calculator().findBigNum(new int[] {4,2,10}));
		assertEquals(-4, new Calculator().findBigNum(new int[] {-4,-12,-10}));

		
	}
	//@Test
	public void testReverse() {
		
		assertEquals("welcome to java", Calculator.reverseApp("emoclew ot avaj"));
	}

}
