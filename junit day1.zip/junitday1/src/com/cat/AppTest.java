package com.cat;

public interface AppTest {

}
