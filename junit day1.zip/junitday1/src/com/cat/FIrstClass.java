package com.cat;

import static org.junit.Assert.fail;

import org.junit.Test;
import org.junit.experimental.categories.Category;

public class FIrstClass {
	
	@Test
	public void test1() {
		fail();
	}
	
	@Category(AppTest.class)
	@Test
	public void test2() {
		 
	}

}
