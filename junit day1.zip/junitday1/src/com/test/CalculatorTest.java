package com.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class CalculatorTest {
	
	int a=1;
	
	@Before
	public void callBefore() {
		a=10;
		System.out.println("called before test");
	}
	@After
	public void callAfter() {
		System.out.println(a);
	}

	@Test
	public void testAdd() {
		++a;
		System.out.println(a);
		assertEquals(10, new Calculator().add(5, 5));
		
	}
	@Test
	public void welcomeTest() {
		++a;
		System.out.println(a);
		assertEquals("welcome", "welcome");
	}
	@Test
	public  void findBigTest() {
		System.out.println(a);
		assertEquals(10, new Calculator().findBigNum(new int[] {4,2,10}));
		assertEquals(-4, new Calculator().findBigNum(new int[] {-4,-12,-10}));

		
	}
	//@Test
	public void testReverse() {
		
		assertEquals("welcome to java", Calculator.reverseApp("emoclew ot avaj"));
	}

}
