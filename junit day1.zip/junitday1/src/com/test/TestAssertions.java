package com.test;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class TestAssertions {
	@Test
	public void compareArray() {
		char [] exp= {'j','a','v','a'};
		char [] actual="java".toCharArray();
		
		assertArrayEquals(exp, actual);
	}
	@Test
	public void testAssertNull() {
		Object data=null;
		assertNull("demo app",data);
	}
	@Test
	public void testAssertsame() {
		Object data=new Object();
		Object data2=new Object();
		assertNotSame(data, data2);
	}

	
	@Test
	public void testAsserttrue() {
		 assertTrue(5>4);
		 assertFalse(5>6);
	}

	
	
}
