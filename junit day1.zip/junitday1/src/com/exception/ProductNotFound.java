package com.exception;

public class ProductNotFound extends Exception{

	public ProductNotFound() {
		super();
		 
	}

}
