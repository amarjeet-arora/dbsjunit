package com.rules;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

public class RulesNew {
	@Rule
	public TemporaryFolder folder= new TemporaryFolder();
	
@Test
	public void testUsingFolder() throws IOException {
		File cf= folder.newFolder("newfolder");
		File crf= folder.newFile("abc.txt");
		assertTrue(crf.exists());
	}
}
