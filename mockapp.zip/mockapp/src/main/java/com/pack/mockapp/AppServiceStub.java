package com.pack.mockapp;

import java.util.Arrays;
import java.util.List;

public class AppServiceStub implements AppService{

	@Override
	public List<String> loadData(String user) {
		 
		return Arrays.asList("admin","manager","qa");
	}

}
